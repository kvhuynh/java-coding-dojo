package com.codingdojo.zookeeper;

public class GorillaTest {
	public static void main(String[] args) {
		Gorilla gorilla = new Gorilla();
		gorilla.displayEnergy();
		gorilla.throwSomething();
		gorilla.throwSomething();
		gorilla.throwSomething();

		gorilla.eatBananas();
		gorilla.eatBananas();

		gorilla.climb();
		
	}
}
