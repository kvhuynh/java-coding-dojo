module CareSoftInterfaces {
}