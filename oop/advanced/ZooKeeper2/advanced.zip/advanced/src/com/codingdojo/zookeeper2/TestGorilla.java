package com.codingdojo.zookeeper2;

public class TestGorilla {
	public static void main(String[] args) {
		Gorilla gorilla = new Gorilla();
		gorilla.displayEnergy();
		gorilla.throwSomething();
		gorilla.throwSomething();
		gorilla.throwSomething();

		gorilla.eatBananas();
		gorilla.eatBananas();

		gorilla.climb();
		
	}
}
