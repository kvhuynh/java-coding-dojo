        // ArrayList<String> passwordSet = generator.getNewPasswordSet(1);
        // System.out.println(passwordSet);