public class FirstProgram {
    public static void main(String[] args) {
        System.out.println("My name is Kevin Huynh");
        System.out.println("I am 22 years old");
        System.out.println("My hometown is Federal Way, WA");
        }
}